-- slider

local image = require "src.common.aUIImage"
local widget = require "src.glove.widgets.widget"

local g = love.graphics
local Slider = widget:extend()
local padding = 3

function Slider:init( progress,onSet)
    self.type = "Slider"
    self.progress = progress or 0
    self.color =  { 0.2, 0.6, 1 }
    self.backColor = { 0.5, 0.5, 0.5 }
    self.onSet=onSet

    self.w = 60 
    self.h = 10 

end

function Slider:draw()
    -- 如果有自动尺寸则用自动尺寸，否则用
    local width = self.w
    local height = self.h

    self.progress=math.max(0, math.min(1, self.progress))

    -- 进度条
    if self:isOver(love.mouse.getPosition()) then
        g.setColor(self.backColor)
        g.rectangle("fill", self.x, self.y, self.w, self.h)

        g.setColor(self.color)
        g.rectangle("fill", self.x, self.y, self.w * self.progress, self.h)
    else
        g.setColor(self.backColor)
        g.rectangle("fill", self.x, self.y, self.w, self.h)

        g.setColor(self.color)
        g.rectangle("fill", self.x, self.y, self.w * self.progress, self.h)
    end
end

function Slider:setSize(w, h)
    self.w = w
    self.h = h
end


function Slider:onDragOver(x, y)
    self:dragProgress(x)
end

--被拖拽
function Slider:onDrag(x, y, dx, dy)
    
    self:justSetProgress(x)
end

function Slider:onClick(x, y, button)
    Glove.setFocus(self)
    self:dragProgress(x)
end

function Slider:justSetProgress(x)
    local ax = self.x
    local width = self.w
    self.progress = (x - ax) / width
    self.progress = math.max(0, math.min(1, self.progress))
end

function Slider:dragProgress(x)
    local ax = self.x
    local width = self.w
    self.progress = (x - ax) / width
    self.progress = math.max(0, math.min(1, self.progress))
    if self.onSet then
        self.onSet(self.progress)
    end
end

function Slider:setProgress(value)
    self.progress=math.max(0, math.min(1, value))
    self.onSet(self.progress)
end

return  Slider