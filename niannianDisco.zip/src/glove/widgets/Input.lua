local love = require "love"
local widget = require "src.glove.widgets.widget"

local g = love.graphics
local lk = love.keyboard
local padding = 4
--输入变量
local inputCursor

local Input = widget:extend()

-- inputTable：控制的输入对象需要包含到
function Input:init( text, onInput)
  local font = g.getFont()
  self.font = font

  self.type = "Input"

  self.text = text
  self.onInput = onInput
  if self.onInput then
    self.onInput(self.text)
  end

  self:setSize(40, 20)
end

function Input:draw()
  local over = self:isOver(love.mouse.getPosition())
  
  g.setColor(0,0,0)
  g.rectangle("fill", self.x, self.y, self.w, self.h)
  g.setColor(over and Glove.hoverColor or self.color)
  g.rectangle("line", self.x, self.y, self.w, self.h)

  -- Get current value.
  local value = self.text or ""

  -- Find substring of value that fits in width.
  local font = self.font
  -- 最大文字宽度
  local limit = self.w - padding * 2
  local i = 1
  local substr
  local substrWidth
  -- 计算当前文字的宽度
  while true do
    substr = value:utf8sub(i, value:utf8len())
    substrWidth = font:getWidth(substr)
    if substrWidth <= limit then break end
    i = i + 1
  end
  -- local truncated = i > 1

  local x = self.x + padding
  local y = self.y + padding

  g.setColor(self.color)
  g.print(substr, x, y)

  local printCursor=love.timer.getTime()%2>1



  --显示输入光标
  if Glove.isFocused(self) and printCursor then
    if inputCursor then
      -- Draw vertical cursor line.
      local height = font:getHeight()
      local cursorPosition = math.min(inputCursor - i + 1, substr:utf8len())
      local cursorX = x + font:getWidth(substr:utf8sub(1, cursorPosition))
      g.line(cursorX, y, cursorX, y + height)
    end
  end
  
end

--输入框被点击
function Input:onClick(clickX, clickY, button)
  Glove.setFocus(self)
  -- Enable keyboard.
  -- TODO: Is this needed? Maybe only on mobile devices.

  local value = self.text or ""
  inputCursor = value:utf8len()
end

--这个应该是新家的用love settext
function Input:setText(text)
  self.text = text
end

function Input:getFontSize()
  local labelWidth = self.font:getWidth(self.text) + padding * 2
  local labelHeight = self.font:getHeight() + padding * 2
  return labelWidth, labelHeight
end

function Input:keypressed(keyPressed)
  local c = inputCursor

  local value = self.text or ""

  if keyPressed == "backspace" then
    if c > 0 then
      self.text = value:utf8sub(1, c - 1) .. value:utf8sub(c + 1, #value)
      inputCursor = c - 1
    end
    if self.onInput then self.onInput(self.text) end
  elseif keyPressed == "left" then
    if c > 0 then inputCursor = c - 1 end
  elseif keyPressed == "right" then
    if c < #value then inputCursor = c + 1 end
  else
    -- Do not insert printable characters here to avoid duplicate input.
    -- Character insertion is handled by `textinput` (IME and normal letters).
  end
end

-- handle IME / composed text input (supports Chinese)
function Input:textinput(t)
  local c = inputCursor or 0
  local value = self.text or ""
  local head = c == 0 and "" or value:utf8sub(1, c)
  local tail = value:utf8sub(c + 1, value:utf8len())
  self.text = head .. t .. tail
  inputCursor = c + t:utf8len()
  if self.onInput then self.onInput(self.text) end
end

return Input
