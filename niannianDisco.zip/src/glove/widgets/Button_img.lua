local colors = require "src.glove.colors"
local love = require "love"
local widget = require "src.glove.widgets.widget"
local image = require "src.common.aUIImage"

local g = love.graphics
local padding = 10

local Button_img = widget:extend()


function Button_img:init(label, imagepath, func)
    local font = g.getFont()
    self.type = "Button"
    self.font = font
    self.label = label
    self.labelColor = colors.black
    self.clickFunc = func

    self.image = image:new(imagepath, 0, 0, 0, 0)
    self.w,self.h = self.image:getSize()
end

function Button_img:draw()
    local cornerRadius = padding

    --先显示图片
    love.graphics.setColor(self.color)
    if self:isOver(love.mouse.getPosition()) and not love.mouse.isDown(1) then
        local offsetx = padding / 2
        local offsety = padding / 2
        self.image:setPos(self.x - offsetx,self.y - offsety)
        self.image:setSize(self.w+ padding,self.h+ padding)
        self.image:draw()
    else
        self.image:setPos(self.x,self.y)
        self.image:setSize(self.w,self.h)
        self.image:draw()
    end

    g.setColor(self.labelColor)
    g.setFont(self.font)

    --减去字体宽度
    local fw, fh = self:getFontSize()

end

function Button_img:setText(text)
    self.label = text
    Button_img:setSize(0, 0)
end

function Button_img:getFontSize()
    local labelWidth = self.font:getWidth(self.label) + padding * 2
    local labelHeight = self.font:getHeight() + padding * 2
    return labelWidth, labelHeight
end

function Button_img:setSize(w, h)
    self.image:setSize(w,h)
    self.w ,self.h=self.image:getSize()
end

function Button_img:setScale(w,h)
    Button_img.super.setScale(self,w,h)
    self.image:setSize(w,h)
end

function Button_img:onClick(x, y, button)
    --print("click",self.clickFunc)
    --self.clickFunc()
end

function Button_img:onClickOver(x, y,button)
  self.clickFunc()
end

return Button_img

